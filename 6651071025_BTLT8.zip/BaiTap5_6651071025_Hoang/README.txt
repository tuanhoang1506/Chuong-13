Bài 5 - Shop H2 Mobile dùng Vue.js 3 CDN + Bootstrap 5. Mở html/index.html bằng trình duyệt có Internet.
