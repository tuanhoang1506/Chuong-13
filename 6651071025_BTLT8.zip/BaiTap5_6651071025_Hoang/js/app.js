const app = Vue.createApp({
  data() {
    return {
      // Mảng dữ liệu sản phẩm. Vue sẽ dùng v-for để tạo giao diện.
      products: [
        {id:1,ten:"Ốp lưng trong suốt",anh:"../images/case.svg",gia:79000,moTa:"Ốp dẻo, nhẹ, bảo vệ điện thoại hằng ngày.",nhan:"Bán chạy"},
        {id:2,ten:"Tai nghe Bluetooth",anh:"../images/earbuds.svg",gia:259000,moTa:"Thiết kế nhỏ gọn, kết nối không dây.",nhan:"Mới"},
        {id:3,ten:"Củ sạc nhanh 20W",anh:"../images/charger.svg",gia:149000,moTa:"Sạc nhanh, kích thước tiện mang theo.",nhan:"Tiện ích"},
        {id:4,ten:"Cáp sạc Type-C",anh:"../images/cable.svg",gia:59000,moTa:"Dây cáp bền, hỗ trợ sạc và truyền dữ liệu.",nhan:"Giá tốt"},
        {id:5,ten:"Pin dự phòng 10000mAh",anh:"../images/powerbank.svg",gia:329000,moTa:"Bổ sung năng lượng khi đi ra ngoài.",nhan:"Phổ biến"},
        {id:6,ten:"Giá đỡ điện thoại",anh:"../images/stand.svg",gia:89000,moTa:"Góc nhìn linh hoạt khi học tập, xem phim.",nhan:"Mới"},
        {id:7,ten:"Loa mini Bluetooth",anh:"../images/speaker.svg",gia:219000,moTa:"Âm thanh rõ, phù hợp nghe nhạc cá nhân.",nhan:"Ưu đãi"},
        {id:8,ten:"Giá đỡ điện thoại ô tô",anh:"../images/holder.svg",gia:119000,moTa:"Giữ điện thoại chắc chắn trên xe.",nhan:"Tiện ích"}
      ],
      cart: [],
      tuKhoa: ""
    };
  },
  computed: {
    // Số lượng sản phẩm trong giỏ hàng để hiển thị ở thanh menu.
    cartCount() { return this.cart.length; },
    // reduce cộng giá từng sản phẩm để tính tổng tiền.
    tongTien() { return this.cart.reduce((tong, item) => tong + item.gia, 0); },
    // Lọc danh sách theo từ khóa, không phân biệt chữ hoa/thường.
    danhSachLoc() {
      const tuKhoaNho = this.tuKhoa.toLowerCase().trim();
      return this.products.filter(sp => sp.ten.toLowerCase().includes(tuKhoaNho));
    }
  },
  methods: {
    // Thêm sản phẩm vào mảng cart.
    themVaoGio(sanPham) { this.cart.push(sanPham); },
    // Xóa sản phẩm khỏi giỏ hàng theo vị trí index.
    xoaKhoiGio(index) { this.cart.splice(index, 1); },
    // Định dạng giá tiền theo cách hiển thị tiền Việt Nam.
    dinhDangTien(soTien) { return new Intl.NumberFormat("vi-VN").format(soTien) + "đ"; },
    // Thông báo minh họa, bài tập chưa kết nối hệ thống thanh toán.
    datHang() { alert("Cảm ơn bạn! Đây là chức năng minh họa, chưa gửi đơn đến máy chủ."); }
  }
});
app.mount("#app");

/*
Nếu dùng Vanilla JS, mỗi lần thêm/xóa giỏ hàng phải tự querySelector
và cập nhật DOM thủ công — Vue tự động làm điều này nhờ reactivity.
*/
