BÀI TẬP CHƯƠNG 13 - BÀI 2 VÀ BÀI 5
MSSV dùng để đặt tên thư mục: 6651071025

Bài 2: BaiTap2_6651071025_Hoang
- Landing page tiệm bánh Mộc Bakery dùng Tailwind CSS Play CDN.
- Menu mobile được JavaScript xử lý bằng cách toggle class hidden/flex.
- Có 6 loại bánh, câu chuyện thương hiệu, aside ưu đãi, form và footer.
- Comment so sánh utility-first với component-based nằm ngay trước phần Menu bánh.

Bài 5: BaiTap5_6651071025_Hoang
- Shop H2 Mobile dùng Vue.js 3 CDN và Bootstrap 5.
- Có 8 sản phẩm; thêm/xóa giỏ hàng; tính tổng tiền; tìm kiếm theo từ khóa.
- Vue CDN được nhúng trước app.js; sử dụng data, computed, methods, v-for, v-if, v-model, @click.

Hình ảnh SVG là hình minh họa tự tạo và nằm trong images/. Các CDN cần Internet.
Mở html/index.html trong từng thư mục bằng trình duyệt. Kiểm tra responsive ở 375px, 768px, 1280px.
Giá và thông tin cửa hàng là dữ liệu minh họa. Nếu MSSV khác, hãy đổi tên thư mục tương ứng.


GHI CHU PHIEN BAN DE NHIN:
- Hai file HTML đã được xuống dòng và thụt lề rõ ràng theo từng thẻ.
- Hai file CSS đã được tách selector, thuộc tính và dấu ngoặc thành từng dòng.
- Chức năng và nội dung trang được giữ nguyên.
