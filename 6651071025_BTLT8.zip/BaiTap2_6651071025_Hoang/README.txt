Bài 2 - Mộc Bakery dùng Tailwind CSS Play CDN. Mở html/index.html bằng trình duyệt có Internet.
