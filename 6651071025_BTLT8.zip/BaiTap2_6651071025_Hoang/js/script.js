const menuButton = document.getElementById("menu-button");
const navMenu = document.getElementById("nav-menu");
// JavaScript tự xử lý menu mobile vì Tailwind chỉ cung cấp class giao diện.
menuButton.addEventListener("click", function () {
  navMenu.classList.toggle("hidden");
  navMenu.classList.toggle("flex");
  menuButton.textContent = navMenu.classList.contains("hidden") ? "☰" : "✕";
  menuButton.setAttribute("aria-expanded", String(!navMenu.classList.contains("hidden")));
});
// Chọn mục menu trên điện thoại thì đóng menu.
document.querySelectorAll("#nav-menu a").forEach(function(link) {
  link.addEventListener("click", function() {
    if (window.innerWidth < 768) {
      navMenu.classList.add("hidden"); navMenu.classList.remove("flex");
      menuButton.textContent = "☰"; menuButton.setAttribute("aria-expanded", "false");
    }
  });
});
// Form minh họa, trình duyệt kiểm tra required và pattern trước khi gửi.
document.getElementById("order-form").addEventListener("submit", function(event) {
  event.preventDefault();
  document.getElementById("form-message").textContent = "Cảm ơn bạn! Mộc đã nhận thông tin (minh họa).";
  this.reset();
});
